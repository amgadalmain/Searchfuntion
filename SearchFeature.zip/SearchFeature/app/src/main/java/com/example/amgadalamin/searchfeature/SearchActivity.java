package com.example.amgadalamin.searchfeature;

import android.os.Build;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
   // int count = 5;
    String seaechthis;
    EditText searchInput;
    Button searchButton;
    public List<UserData> userdatas = new ArrayList<>();
    UserData ud;

    String[] USERNAMES = new String[100];
    String[] USERPOSTS = new String[100];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        searchInput = (EditText) findViewById(R.id.search_field);

        searchButton = (Button) findViewById(R.id.searchbtn);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seaechthis = searchInput.getText().toString();

                readUserData(seaechthis);

                ListView listView = (ListView) findViewById(R.id.result_list);

                CustomAdapter customAdapter = new CustomAdapter();
                listView.setAdapter(customAdapter);


            }
        });



    }


    class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return 100;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = getLayoutInflater().inflate(R.layout.list_layout,null);
            TextView textView_name = (TextView) view.findViewById(R.id.name_text);
            TextView textView_post = (TextView) view.findViewById(R.id.post_text);

            textView_name.setText(USERNAMES[i]);
            textView_post.setText(USERPOSTS[i]);
            return view;
        }
    }



    private void readUserData(String seaechthis) {

      InputStream is = getResources().openRawResource(R.raw.data);
        BufferedReader reader = new BufferedReader(

                new InputStreamReader(is, Charset.forName("UTF-8"))
        );

        String line = "";
        try {
            //step over header
            reader.readLine();

            int i = 0;
            while ((line = reader.readLine()) != null) {
                //split br ,

                String[] tokens = line.split(",");
                //Read data
                UserData user = new UserData();
                user.setName(tokens[0]);

                user.setpost(tokens[3]);
                // user.serIntNumber(Integer.parseInt(token[1]));

                if (tokens[3].contains(seaechthis) || tokens[3].contains(" "+seaechthis+".") || tokens[3].contains(seaechthis+" ") || tokens[3].contains(" "+seaechthis+" ") || tokens[0].contains(seaechthis)) {
                if (i <= 99)
                {
                    USERNAMES[i] = tokens[0];
                    USERPOSTS[i] = tokens[3];
                i++;
                 }
                    userdatas.add(user);
                }

                Log.d("MyActivity", "Just created " + user);
            }
        } catch (IOException e) {
            Log.wtf("MyActivity", "Error reading data on line" + line, e);
            e.printStackTrace();
        }
    }



}
