package com.example.amgadalamin.searchfeature;


class UserData {
    public String name,  post;

    public UserData(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getpost() {
        return post;
    }

    public void setpost(String post) {
        this.post = post;
    }

    public UserData(String name,  String post) {
        this.name = name;
        this.post = post;
    }

    @Override
    public String toString() {
        return "UserData{" +
                "name='" + name + '\'' +
                ", post='" + post + '\'' +
                '}';
    }
}